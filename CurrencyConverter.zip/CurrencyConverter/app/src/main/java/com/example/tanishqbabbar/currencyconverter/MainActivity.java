package com.example.tanishqbabbar.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void onClick(View view) {

        EditText editText = (EditText) findViewById(R.id.editText);
        double amount = Double.parseDouble(editText.getText().toString());
        String str = String.valueOf(amount * 1.3);
        String.format(str, "%.2f");

        Toast.makeText(this, "Amount in Dollars: " + str, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
