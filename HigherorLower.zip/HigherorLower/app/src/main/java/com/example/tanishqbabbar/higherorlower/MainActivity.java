package com.example.tanishqbabbar.higherorlower;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int number;

    public void generate() {

        Random rand = new Random();
        number = rand.nextInt(20) + 1;

    }

    public void onClick(View view) {

        EditText editText = (EditText)findViewById(R.id.editText);
        String numstr = editText.getText().toString();
        double num = Double.parseDouble(numstr);

        String message;

        if(num > number)
            message = "Lower";
        else if(num < number)
            message = "Higher";
        else {
            message = "Congrats, you got it!!";
            generate();
        }


        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        Log.i("Value", Integer.toString(number));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generate();

    }
}
